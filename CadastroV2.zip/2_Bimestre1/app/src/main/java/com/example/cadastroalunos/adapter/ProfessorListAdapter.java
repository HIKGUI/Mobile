package com.example.cadastroalunos.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cadastroalunos.R;
import com.example.cadastroalunos.model.Professor;

import java.util.ArrayList;

public class ProfessorListAdapter extends RecyclerView.Adapter<ProfessorListAdapter.ViewHolder> {

    private ArrayList<Professor> listaProfessor;
    private Context context;

    public ProfessorListAdapter(ArrayList<Professor> listaProfessor,
                            Context context) {
        this.listaProfessor = listaProfessor;
        this.context = context;
    }

    /**
     * Método responsável em carregar o
     * arquivo xml para cada elemento da lista
     * @return
     */
    @NonNull
    @Override
    public ProfessorListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater =
                LayoutInflater.from(parent.getContext());

        View listItem =
                inflater.inflate(R.layout.item_list_professor,
                        parent, false);

        return new ProfessorListAdapter.ViewHolder(listItem);
    }

    /**
     * Método responsável em escrever os dados no layout
     */
    @Override
    public void onBindViewHolder(@NonNull ProfessorListAdapter.ViewHolder holder, int position) {
        Professor professor = listaProfessor.get(position);
        holder.tvMatricula.setText(String.valueOf(professor.getMatricula()));
        holder.tvNome.setText(professor.getNome());
        holder.tvDisciplina.setText(professor.getDisciplina());
        holder.tvDtAdmissao.setText(professor.getDtAdmissao());
    }

    @Override
    public int getItemCount() {
        return listaProfessor.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView tvMatricula, tvNome, tvDisciplina, tvDtAdmissao;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            this.tvMatricula = itemView.findViewById(R.id.tvMatricula);
            this.tvNome = itemView.findViewById(R.id.tvNome);
            this.tvDisciplina = itemView.findViewById(R.id.tvDisciplina);
            this.tvDtAdmissao = itemView.findViewById(R.id.tvDtAdmissao);
        }
    }

}
