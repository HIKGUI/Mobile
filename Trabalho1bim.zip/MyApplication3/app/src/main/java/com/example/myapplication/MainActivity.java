package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView tvError_nome;
    private TextView tvError_Email;
    private TextView tvError_Idade;
    private TextView tvError_Diciplina;
    private TextView tvError_1Bimestre;
    private TextView tvError_2Bimestre;
    private TextView tvResultado;


    private EditText edname;
    private EditText edEmail;
    private EditText edidade;
    private EditText edDiscipina;
    private EditText ednt1Bimestre;
    private EditText ednt2Bimestre;


    private Button btConfirmar;
    private Button btLimpar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvError_nome = findViewById(R.id.Error_nome);
        tvError_Email = findViewById(R.id.Error_Email);
        tvError_Idade = findViewById(R.id.Error_Idade);
        tvError_Diciplina = findViewById(R.id.Error_Diciplina);
        tvError_1Bimestre = findViewById(R.id.Error_1Bimestre);
        tvError_2Bimestre = findViewById(R.id.Error_2Bimestre);
        tvResultado = findViewById(R.id.Resultado);
        edname = findViewById(R.id.name);
        edEmail = findViewById(R.id.Email);
        edidade = findViewById(R.id.idade);
        edDiscipina = findViewById(R.id.Discipina);
        ednt1Bimestre = findViewById(R.id.nt1Bimestre);
        ednt2Bimestre = findViewById(R.id.nt2Bimestre);
        btConfirmar = findViewById(R.id.bt_confirmar);
        btLimpar = findViewById(R.id.bt_limpar);


        btConfirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Verificar();


            }
        });


        btLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Limpar();
            }
        });








    }






    private void Verificar() {


        //int idade = Integer.parseInt(edidade.getText().toString());
        String idade = edidade.getText().toString();
        String nome = edname.getText().toString();
        String email = edEmail.getText().toString();
        String disciplina = edDiscipina.getText().toString();
        String nt1bimestre = ednt1Bimestre.getText().toString();
        String nt2bimestre = ednt2Bimestre.getText().toString();
        boolean tes_nome = false, tes_email = false, tes_idade = false, tes_disciplina = false, tes_1bimestre = false, tes_2bimestre = false;
        double nt1bimestres = 0;
        double nt2bimestres = 0;
        int age = 0;




        if(nome.equals("")){
            tvError_nome.setText("O campo de nome está vazio");
        }else{
            tes_nome = true;
        }
        if(email.equals("")){
            tvError_Email.setText("O email está vazio");
        }else if(email.contains("@")){

            if(email.indexOf("@")<5){
                tvError_Email.setText("O email invalido");
            }else{
                tes_email = true;
            }
        }
        if(idade.equals("")) {

            tvError_Idade.setText("Campo idade esta vazio");
        }else{

            age = Integer.parseInt(edidade.getText().toString());
            if((age > 0) && (age <=100)) {
                tes_idade = true;
            }
        }
        if(disciplina.equals("")){
            tvError_Diciplina.setText("Campo disciplina invalido!!");
        }else{
            tes_disciplina = true;
        }
        if(nt1bimestre.equals("")){
            tvError_1Bimestre.setText("Campo 1 bimestre invalido!!");
        }else{
            nt1bimestres = Double.parseDouble(ednt1Bimestre.getText().toString());
            if((nt1bimestres >= 0) && (nt1bimestres <=10)){

                tes_1bimestre = true;
            }
        }
        if(nt2bimestre.equals("")){
            tvError_2Bimestre.setText("Campo 2 bimestre invalido!!");
        }else{
            nt2bimestres = Double.parseDouble(ednt2Bimestre.getText().toString());

            if((nt2bimestres >= 0) && (nt2bimestres <=10)) {

                tes_2bimestre = true;
            }
        }


        if((tes_nome == true) && (tes_email == true) &&  (tes_idade == true) && (tes_disciplina == true) && (tes_1bimestre == true) && (tes_2bimestre == true)){


            double soma = nt1bimestres + nt2bimestres;
            double media = soma/2;
            String result = "";

            if(media >= 6){
                result = "Aluno aprovado";
            }else{
                result = "Aluno reprovado";
            }

            tvResultado.setText("Nome: " + nome + "\n" +
                    "Email: " + email + "\n" +
                    "Idade: " + age + "\n" +
                    "Disciplina: " + disciplina + "\n" +
                    "Notas 1o e 2o Bimestres: " + soma + "\n" +
                    "Média: " + media + "\n" +
                    result
            );

        } else {
            tvResultado.setText("Verificar informações, dados incorretos");
        }






    }


    private void Limpar() {
        edname.setText("");
        edEmail.setText("");
        edidade.setText("");
        edDiscipina.setText("");
        ednt1Bimestre.setText("");
        ednt2Bimestre.setText("");
        tvResultado.setText("");
        tvError_1Bimestre.setText("");
        tvError_2Bimestre.setText("");
        tvError_Diciplina.setText("");
        tvError_Email.setText("");
        tvError_Idade.setText("");
        tvError_nome.setText("");
    }

}